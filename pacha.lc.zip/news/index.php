<?php
include ($_SERVER['DOCUMENT_ROOT'].'/components/template/header.php');

app::title("news");
include_once($_SERVER['DOCUMENT_ROOT'].'/components/news/newslist/template.php');

include ($_SERVER['DOCUMENT_ROOT'].'/components/template/footer.php');