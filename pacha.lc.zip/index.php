<?php
header('Location: /news/');
exit;